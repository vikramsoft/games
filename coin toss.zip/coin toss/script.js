let isPaused = false;
let gameInterval;

const coin = document.getElementById("coin");
const startButton = document.getElementById("start");
const pauseButton = document.getElementById("pause");
const quitButton = document.getElementById("quit");

function startGame() {
    if (gameInterval) clearInterval(gameInterval);
    isPaused = false;
    tossCoin();
}

function pauseGame() {
    if (!isPaused) {
        isPaused = true;
        pauseButton.textContent = "Resume";
        clearInterval(gameInterval);
    } else {
        isPaused = false;
        pauseButton.textContent = "Pause";
        tossCoin();
    }
}

function quitGame() {
    clearInterval(gameInterval);
    alert("Game is closed");
}

function tossCoin() {
    coin.textContent = "Tossing...";
    coin.style.transform = "rotateY(0deg)"; // Reset rotation
    let startTime = Date.now();
    
    gameInterval = setInterval(() => {
        if (Date.now() - startTime < 5000) {
            // Simulate toss animation
            coin.style.transform = `rotateY(${Math.random() * 360}deg)`;
        } else {
            clearInterval(gameInterval);
            showResult();
        }
    }, 100);
}

function showResult() {
    const result = Math.random() < 0.5 ? "Heads" : "Tails";
    coin.textContent = result;
}

startButton.addEventListener("click", startGame);
pauseButton.addEventListener("click", pauseGame);
quitButton.addEventListener("click", quitGame);
