const canvas = document.getElementById('gameCanvas');
const ctx = canvas.getContext('2d');
canvas.width = window.innerWidth;
canvas.height = window.innerHeight;

let bucket = {
    x: canvas.width / 2 - 50,
    width: 100,
    height: 20,
    color: 'white',
};

let balls = [];
let score = 0;
let ballColors = ['red', 'green', 'yellow'];
let gameOver = false;
let totalBalls = 50;
let ballsDropped = 0;

function drawBucket() {
    ctx.fillStyle = bucket.color;
    ctx.fillRect(bucket.x, canvas.height - bucket.height, bucket.width, bucket.height);
}

function createBall() {
    if (ballsDropped < totalBalls) {
        const x = Math.random() * (canvas.width - 20);
        const color = ballColors[Math.floor(Math.random() * ballColors.length)];
        balls.push({ x: x, y: 0, radius: 10, color: color });
        ballsDropped++;
    }
}

function drawBalls() {
    balls.forEach((ball, index) => {
        ctx.fillStyle = ball.color;
        ctx.beginPath();
        ctx.arc(ball.x, ball.y, ball.radius, 0, Math.PI * 2);
        ctx.fill();
        ball.y += 3; // Fall speed

        // Check for catch
        if (ball.y + ball.radius >= canvas.height - bucket.height &&
            ball.x > bucket.x && ball.x < bucket.x + bucket.width) {
            balls.splice(index, 1);
            score++;
        }

        // Remove balls that fall off screen
        if (ball.y > canvas.height) {
            balls.splice(index, 1);
        }
    });
}

function updateScore() {
    const scoreDiv = document.getElementById('score');
    scoreDiv.textContent = `Score: ${score}`;
}

function handleKeyDown(event) {
    if (!gameOver) {
        if (event.key === 'ArrowLeft') {
            bucket.x -= 20;
            if (bucket.x < 0) bucket.x = 0;
        } else if (event.key === 'ArrowRight') {
            bucket.x += 20;
            if (bucket.x + bucket.width > canvas.width) {
                bucket.x = canvas.width - bucket.width;
            }
        }
    }
}

function gameLoop() {
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    drawBucket();
    drawBalls();
    updateScore();

    if (!gameOver) {
        requestAnimationFrame(gameLoop);
    }

    // Check if all balls have been dropped
    if (ballsDropped >= totalBalls && balls.length === 0) {
        gameOver = true;
        ctx.fillStyle = 'white';
        ctx.font = '48px Arial';
        ctx.fillText('Game Over!', canvas.width / 2 - 100, canvas.height / 2);
        ctx.fillText(`Final Score: ${score}`, canvas.width / 2 - 100, canvas.height / 2 + 50);
    }
}

function startGame() {
    gameOver = false;
    score = 0;
    balls = [];
    ballsDropped = 0;
    document.getElementById('startButton').style.display = 'none'; // Hide start button
    gameLoop(); // Start the game loop
    setInterval(createBall, 1000); // Create a ball every second
}

document.getElementById('startButton').onclick = startGame;
document.addEventListener('keydown', handleKeyDown);
