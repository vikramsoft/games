let gameInterval;
let isPaused = false;
let coinElement = document.getElementById('coin');
let coinImage = document.getElementById('coinImage');

// Array of image URLs (replace with your actual image paths)
const images = [
    'img/img1.png',
    'img/img2.png',
    'img/img3.png',
    'img/img4.png',
    'img/img5.png',
 
];

document.getElementById('startButton').addEventListener('click', startGame);
document.getElementById('pauseButton').addEventListener('click', togglePause);
document.getElementById('quitButton').addEventListener('click', quitGame);

function startGame() {
    resetGame();
    animateCoin();
}

function resetGame() {
    clearInterval(gameInterval);
    isPaused = false;
    coinElement.style.display = 'flex'; // Ensure coin is visible
    coinImage.src = ''; // Reset image
}

function animateCoin() {
    let duration = 5000; // 5 seconds
    let endTime = Date.now() + duration;

    gameInterval = setInterval(() => {
        if (Date.now() > endTime || isPaused) {
            clearInterval(gameInterval);
            return;
        }

        let randomIndex = Math.floor(Math.random() * images.length);
        coinImage.src = images[randomIndex]; // Change image
        coinElement.style.transform = `translateY(-20px)`;

        setTimeout(() => {
            coinElement.style.transform = `translateY(0)`;
        }, 100);
    }, 100);
}

function togglePause() {
    if (isPaused) {
        isPaused = false;
        document.getElementById('pauseButton').textContent = 'Pause';
        animateCoin();
    } else {
        isPaused = true;
        document.getElementById('pauseButton').textContent = 'Resume';
        clearInterval(gameInterval);
    }
}

function quitGame() {
    clearInterval(gameInterval);
    alert('Game is closed');
    resetGame();
}
