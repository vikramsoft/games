let gameInterval;
let isPaused = false;
let coinElement = document.getElementById('coin');

document.getElementById('startButton').addEventListener('click', startGame);
document.getElementById('pauseButton').addEventListener('click', togglePause);
document.getElementById('quitButton').addEventListener('click', quitGame);

function startGame() {
    resetGame();
    animateCoin();
}

function resetGame() {
    clearInterval(gameInterval);
    isPaused = false;
    coinElement.style.display = 'flex'; // Ensure coin is visible
    coinElement.textContent = '0'; // Reset to 0
}

function animateCoin() {
    let duration = 5000; // 5 seconds
    let endTime = Date.now() + duration;

    gameInterval = setInterval(() => {
        if (Date.now() > endTime || isPaused) {
            clearInterval(gameInterval);
            return;
        }

        let randomValue = Math.floor(Math.random() * 10) + 1;
        coinElement.textContent = randomValue; // Update the number
        coinElement.style.transform = `translateY(-20px)`;

        setTimeout(() => {
            coinElement.style.transform = `translateY(0)`;
        }, 100);
    }, 100);
}

function togglePause() {
    if (isPaused) {
        isPaused = false;
        document.getElementById('pauseButton').textContent = 'Pause';
        animateCoin();
    } else {
        isPaused = true;
        document.getElementById('pauseButton').textContent = 'Resume';
        clearInterval(gameInterval);
    }
}

function quitGame() {
    clearInterval(gameInterval);
    alert('Game is closed');
    resetGame();
}
